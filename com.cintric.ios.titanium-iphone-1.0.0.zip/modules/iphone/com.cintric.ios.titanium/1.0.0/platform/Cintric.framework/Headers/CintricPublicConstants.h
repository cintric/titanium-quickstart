//
//  CintricPublicConstants.h
//  Cintric
//
//  Created by Joel Green on 11/10/15.
//  Copyright © 2015 Cintric. All rights reserved.
//

#ifndef CintricPublicConstants_h
#define CintricPublicConstants_h

#import <CoreLocation/CoreLocation.h>
typedef void (^cintricDidUpdateLocation)(CLLocation *);

#endif /* CintricPublicConstants_h */
